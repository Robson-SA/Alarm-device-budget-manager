package com.devsquard.security.alarmbudget.dto;

public class ItemDoProjetoInsertDTO {

	private Long produtoId;
    private Long projetoId;
    private Integer quantidade;
    private String observacao;
	public Long getProdutoId() {
		return produtoId;
	}
	public void setProdutoId(Long produtoId) {
		this.produtoId = produtoId;
	}
	public Long getProjetoId() {
		return projetoId;
	}
	public void setProjetoId(Long projetoId) {
		this.projetoId = projetoId;
	}
	public Integer getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}
	public String getObservacao() {
		return observacao;
	}
	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}
    
    
    
	
}
