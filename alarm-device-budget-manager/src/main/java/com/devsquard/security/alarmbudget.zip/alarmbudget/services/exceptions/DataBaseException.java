package com.devsquard.security.alarmbudget.services.exceptions;

public class DataBaseException extends RuntimeException {
    public DataBaseException(String msg){
        super(msg);
    }

}
